**Período analisado**: r start\_date até r end\_date

    # Ajuste do modelo de regressão linear
    modelo <- lm(score_final ~ prod + short_count + nc_ratio + icra + iatd, data = df)

    # Sumário completo
    summary(modelo)

    ## 
    ## Call:
    ## lm(formula = score_final ~ prod + short_count + nc_ratio + icra + 
    ##     iatd, data = df)
    ## 
    ## Residuals:
    ##        Min         1Q     Median         3Q        Max 
    ## -2.912e-14 -5.050e-17 -8.000e-19  7.280e-17  3.057e-14 
    ## 
    ## Coefficients:
    ##               Estimate Std. Error    t value Pr(>|t|)    
    ## (Intercept)  1.000e+00  1.293e-15  7.734e+14  < 2e-16 ***
    ## prod        -1.215e-18  1.223e-18 -9.940e-01    0.321    
    ## short_count  1.183e-16  5.052e-18  2.341e+01  < 2e-16 ***
    ## nc_ratio    -4.354e-15  9.548e-16 -4.560e+00 5.37e-06 ***
    ## icra         1.000e+00  4.256e-17  2.350e+16  < 2e-16 ***
    ## iatd        -1.000e+00  1.308e-15 -7.648e+14  < 2e-16 ***
    ## ---
    ## Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    ## 
    ## Residual standard error: 9.188e-16 on 2369 degrees of freedom
    ## Multiple R-squared:      1,  Adjusted R-squared:      1 
    ## F-statistic: 1.659e+32 on 5 and 2369 DF,  p-value: < 2.2e-16

    # Resumo em formato tidy (opcional)
    tidy(modelo)

    ## # A tibble: 6 × 5
    ##   term         estimate std.error statistic   p.value
    ##   <chr>           <dbl>     <dbl>     <dbl>     <dbl>
    ## 1 (Intercept)  1.00e+ 0  1.29e-15  7.73e+14 0        
    ## 2 prod        -1.22e-18  1.22e-18 -9.94e- 1 3.21e-  1
    ## 3 short_count  1.18e-16  5.05e-18  2.34e+ 1 3.18e-109
    ## 4 nc_ratio    -4.35e-15  9.55e-16 -4.56e+ 0 5.37e-  6
    ## 5 icra         1.00e+ 0  4.26e-17  2.35e+16 0        
    ## 6 iatd        -1   e+ 0  1.31e-15 -7.65e+14 0

    glance(modelo)

    ## # A tibble: 1 × 12
    ##   r.squared adj.r.squared    sigma statistic p.value    df logLik      AIC
    ##       <dbl>         <dbl>    <dbl>     <dbl>   <dbl> <dbl>  <dbl>    <dbl>
    ## 1         1             1 9.19e-16   1.66e32       0     5 78864. -157713.
    ## # ℹ 4 more variables: BIC <dbl>, deviance <dbl>, df.residual <int>, nobs <int>
