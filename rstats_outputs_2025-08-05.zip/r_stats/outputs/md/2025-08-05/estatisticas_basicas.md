**Período analisado**: r start\_date até r end\_date

    df %>% 
      select(prod, short_count, nc_ratio, score_final, icra, iatd) %>% 
      summary()

    ##       prod        short_count         nc_ratio        score_final     
    ##  Min.   : 0.06   Min.   : 0.0000   Min.   :0.00000   Min.   :0.00000  
    ##  1st Qu.: 1.69   1st Qu.: 0.0000   1st Qu.:0.02445   1st Qu.:0.02510  
    ##  Median :10.91   Median : 0.0000   Median :0.03797   Median :0.03303  
    ##  Mean   :15.64   Mean   : 0.5718   Mean   :0.04438   Mean   :0.19559  
    ##  3rd Qu.:26.45   3rd Qu.: 0.0000   3rd Qu.:0.05619   3rd Qu.:0.04827  
    ##  Max.   :75.02   Max.   :80.0000   Max.   :0.44048   Max.   :3.37237  
    ##       icra             iatd       
    ##  Min.   :0.0000   Min.   :0.6276  
    ##  1st Qu.:0.0000   1st Qu.:0.9553  
    ##  Median :0.0000   Median :0.9676  
    ##  Mean   :0.1571   Mean   :0.9615  
    ##  3rd Qu.:0.0000   3rd Qu.:0.9752  
    ##  Max.   :3.0000   Max.   :1.0000

    m <- cor(df %>% select(prod, short_count, nc_ratio, score_final, icra, iatd),
             use = "complete.obs")
    corrplot(m, method = "number")

![](/home/gustavodetarso/Documentos/atestmed-defender/r_stats/outputs/md/2025-08-05/estatisticas_basicas_files/figure-markdown_strict/correlacao-1.png)

    ggplot(df, aes(x = grupo, y = score_final)) +
      geom_boxplot(fill = "skyblue") +
      theme_minimal() +
      labs(
        title    = "Score Final - Top 10 vs Nacional",
        subtitle = paste(start_date, "até", end_date),
        x        = "Grupo",
        y        = "Score Final"
      )

![](/home/gustavodetarso/Documentos/atestmed-defender/r_stats/outputs/md/2025-08-05/estatisticas_basicas_files/figure-markdown_strict/boxplot_sc_final_por_grupo-1.png)
