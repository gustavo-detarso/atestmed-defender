**Período analisado**: r start\_date até r end\_date

    ggplot(df, aes(x = reorder(cr, -score_final, FUN = mean, na.rm = TRUE),
                   y = score_final)) +
      geom_boxplot(fill = "#FFDD87") +
      theme_minimal() +
      labs(
        title = "Score Final por CR",
        subtitle = paste(start_date, "até", end_date),
        x = "CR",
        y = "Score Final"
      )

![](/home/gustavodetarso/Documentos/atestmed-defender/r_stats/outputs/md/2025-08-05/analise_cr_dr_files/figure-markdown_strict/boxplot_por_cr-1.png)

    # ANOVA para CR
    anova_cr <- aov(score_final ~ cr, data = df)
    cat("### ANOVA por CR\n")

    ## ### ANOVA por CR

    print(summary(anova_cr))

    ##               Df Sum Sq Mean Sq F value  Pr(>F)   
    ## cr             5    4.8  0.9644   3.281 0.00589 **
    ## Residuals   2366  695.5  0.2939                   
    ## ---
    ## Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    ## 3 observations deleted due to missingness

    cat("\n---\n\n")

    ## 
    ## ---

    # ANOVA para DR
    anova_dr <- aov(score_final ~ dr, data = df)
    cat("### ANOVA por DR\n")

    ## ### ANOVA por DR

    print(summary(anova_dr))

    ##               Df Sum Sq Mean Sq F value   Pr(>F)    
    ## dr            32   21.7  0.6783   2.333 3.59e-05 ***
    ## Residuals   2331  677.6  0.2907                     
    ## ---
    ## Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    ## 11 observations deleted due to missingness
