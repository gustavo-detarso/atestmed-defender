**Período analisado:** 2025-07-01 até 2025-07-31

    estat_desc <- df %>%
      group_by(grupo) %>%
      summarise(
        media_score = mean(score_final, na.rm = TRUE),
        sd_score    = sd(score_final,   na.rm = TRUE),
        media_icra  = mean(icra,         na.rm = TRUE),
        sd_icra     = sd(icra,          na.rm = TRUE),
        media_iatd  = mean(iatd,         na.rm = TRUE),
        sd_iatd     = sd(iatd,          na.rm = TRUE)
      )
    print(estat_desc)

    ## # A tibble: 1 × 7
    ##   grupo  media_score sd_score media_icra sd_icra media_iatd sd_iatd
    ##   <chr>        <dbl>    <dbl>      <dbl>   <dbl>      <dbl>   <dbl>
    ## 1 Outros       0.196    0.543      0.157   0.533      0.961  0.0256

    variaveis <- c("score_final", "icra", "iatd")

    for (var in variaveis) {
      cat("### Variável:", var, "\n")
      top10  <- df %>% filter(grupo == "Top10") %>% pull(var) %>% na.omit()
      outros <- df %>% filter(grupo == "Outros") %>% pull(var)  %>% na.omit()
      
      # t-test
      if (length(top10) > 1 && length(outros) > 1) {
        print(t.test(top10, outros))
      } else {
        cat("t-test não executado (amostras insuficientes)\n")
      }
      
      # Wilcoxon
      if (length(top10) > 0 && length(outros) > 0) {
        print(wilcox.test(top10, outros))
      } else {
        cat("Wilcoxon não executado (amostras insuficientes)\n")
      }
      
      cat("\n---\n\n")
    }

    ## ### Variável: score_final 
    ## t-test não executado (amostras insuficientes)
    ## Wilcoxon não executado (amostras insuficientes)
    ## 
    ## ---
    ## 
    ## ### Variável: icra 
    ## t-test não executado (amostras insuficientes)
    ## Wilcoxon não executado (amostras insuficientes)
    ## 
    ## ---
    ## 
    ## ### Variável: iatd 
    ## t-test não executado (amostras insuficientes)
    ## Wilcoxon não executado (amostras insuficientes)
    ## 
    ## ---
