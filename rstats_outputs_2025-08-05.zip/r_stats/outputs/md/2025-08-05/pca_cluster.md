**Período analisado:** 2025-07-01 até 2025-07-31

    res.pca <- PCA(df, graph = FALSE)
    fviz_pca_var(res.pca, col.var = "contrib")

![](/home/gustavodetarso/Documentos/atestmed-defender/r_stats/outputs/md/2025-08-05/pca_cluster_files/figure-markdown_strict/pca-1.png)

    km <- kmeans(scale(df), centers=3)
    fviz_cluster(km, data=scale(df), ellipse.type="euclid")

![](/home/gustavodetarso/Documentos/atestmed-defender/r_stats/outputs/md/2025-08-05/pca_cluster_files/figure-markdown_strict/k-means_clustering-1.png)
